#-*-coding: UTF-8-*-
#####Units: Length-m, Force-kN, mass-ton, Stress-kpa(10e-3MPa), g=9.81m/s2
#####Units: Length-mm, Force-N, mass-ton, Stress-Mpa, g=9810mm/s2 pho=ton/mm3
#########################################################################
#  Author: Junjun Guo
#  E-mail: guojj@tongji.edu.cn/guojj_ce@163.com/guojj01@gmail.com
#  Environemet: Successfully executed in python 3.8
#  Date: 2022-01-29
#########################################################################
######################---import necessray modules---#####################
from openseespy.opensees import *
import numpy as np
#########################################################################
def earthquakeExcite(waveNumber=1):
    """
    Ground motion input function
    waveNumber(int)-the ground motion number
    """
    dampingRatio=0.03
    ##Longitudinal damping coefficients T1=12.68s T247=0.125s
    a=dampingRatio*2.0*0.4955*50.265/float(0.4955+50.265)
    b=dampingRatio*2/float(0.4955+50.265)
    ##Transverse damping coefficients T2=4.715s T257=0.121s
    # a = dampingRatio * 2.0 * 1.3326 * 51.927/ float(1.3326 +51.927)
    # b = dampingRatio * 2 / float(1.3326 + 51.927)
    ### D=α×M＋β1×Kcurrent＋β2×Kinit＋β3×KlastCommit Longitudinal direction
    rayleigh(a,0.0, b, 0.0)
    print('rayleigh damping: ',a,b)
    loadConst('-time', 0.0)
    waveLength=np.loadtxt('length.txt')
    currentLength=int(waveLength[waveNumber-1])
    dtList=np.loadtxt('dt.txt')
    currentDt=float(dtList[waveNumber-1])
    dir_L,dir_T,dir_V=1,2,3
    gmFact=9.81
    acc_X='inputGroundMotion/horizontal/'+str(waveNumber)+'.txt'
    acc_Z = 'inputGroundMotion/vertical/' + str(waveNumber) + '.txt'
    timeSeries('Path',11, '-dt',currentDt,'-filePath',acc_X,'-factor',gmFact)
    timeSeries('Path', 12, '-dt', currentDt, '-filePath', acc_Z, '-factor', gmFact)
    pattern('UniformExcitation', 111,dir_L, '-accel',11)
    pattern('UniformExcitation', 112, dir_V, '-accel', 12)
    ######################################################
    wipeAnalysis()
    test('NormDispIncr', 1.0e-8, 100)
    algorithm('NewtonLineSearch')
    integrator('Newmark',0.5,0.25)
    system('UmfPack')
    constraints('Transformation')
    numberer('RCM')
    analysis('Transient')
    ######################################################
    import time
    startTime=time.perf_counter()
    tCurrent = getTime()
    tFinal=currentLength*currentDt
    testList = ['NormDispIncr','RelativeEnergyIncr','EnergyIncr','RelativeNormUnbalance',
            'RelativeNormDispIncr','NormUnbalance']
    algorithmList = ['KrylovNewton','SecantNewton','ModifiedNewton','RaphsonNewton','PeriodicNewton',
                 'BFGS', 'Broyden','NewtonLineSearch']
    tolList=[1.0e-8,1.0e-7,1.0e-6,1.0e-5,1.0e-4,1.0e-3,1.0e-2]
    maxIterNumList=[50,100,150,200,250,300,350]
    stepList=[1.0,0.5,0.25,0.125,0.0625]
    timeList=[tCurrent]
    ok=0
    while(tCurrent<tFinal):
        for i in range(len(testList)):
            for j in range(len(algorithmList)):
                for k in range(len(tolList)):
                    if j<4:
                        algorithm(algorithmList[j], '-initial')
                    else:
                        algorithm(algorithmList[j])
                    while(ok==0 and tCurrent<tFinal):
                        test(testList[i],tolList[k],maxIterNumList[k])
                        NewmarkGamma = 0.5
                        NewmarkBeta = 0.25
                        integrator('Newmark', NewmarkGamma, NewmarkBeta)
                        analysis('Transient')
                        ok = analyze(1,currentDt)
                        if(ok==0):
                            tCurrent = getTime()
                            timeList.append(tCurrent)
                            endTime=time.perf_counter()
                            realTime=endTime-startTime
                            print(testList[i], algorithmList[j],'Tol=',tolList[k],'maxIter=',maxIterNumList[k],
                            'ground motion=',waveNumber,'totalTime=',tFinal,'tCurrent=', "{:.6f}".format(tCurrent),
                            'time cost=',"{:.1f}".format(realTime),'second')
                            if k!=0:
                                k-=1








